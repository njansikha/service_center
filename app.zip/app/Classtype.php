<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classtype extends Model
{
    //

    protected $table = 'classtype';
    protected $fillable = [
        'classtype',
    ];
}
