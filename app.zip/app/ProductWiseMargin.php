<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductWiseMargin extends Model
{
    //
    protected $table = 'productwisemargin';
    protected $fillable = [
        'productid','margintype','amount','serialnumber',
    ];
}
