<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class AreaopOf extends Model
{
    //

    protected $table = 'areaof';
    protected $fillable = [
        'area'
    ];

}
