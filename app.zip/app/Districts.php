<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Districts extends Model
{
    //

    protected $table = 'Districts';
    protected $fillable = [
        'state','district'
    ];
}
