<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class CompanyProfile extends Model
{
    //

    protected $table = 'companyprofile';
    protected $fillable = [
        'compayname','emailid','contactnumber','Address','logothumb',
        'logoactual','starttime','endtime','workinghours','shortcode','gstno',
        'workingdays','year','addedby','editedby',
        'sunday','monday','tuesday','wednesday','thursday','friday','saturday'
    ];
}
