<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Batch extends Model
{
    //

    protected $table = 'batch';
    protected $fillable = [
        'batchname','batchno','batchtiming','startday','endday','classtype','addedby','editedby'
    ];
}
