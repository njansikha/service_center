<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class LeadTag extends Model
{
    //

    protected $table = 'leadtag';
    protected $fillable = [
        'leadtag',
    ];
}
