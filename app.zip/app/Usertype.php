<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Usertype extends Model
{
    //

    protected $table = 'usertype';
    protected $fillable = [
        'usertype','masterdata','lead','product','staff',
    ];
}
