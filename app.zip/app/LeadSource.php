<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class LeadSource extends Model
{
    //

    protected $table = 'leadsource';
    protected $fillable = [
        'leadsource',
    ];
}