<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //
    protected $table = 'product';
    protected $fillable = [
        'productname','specification','modelnumber','serialnumber','price','landing_expense',
        'margin_oem','margin_enduser','vendorname','supplieddate','addedby','editedby','warentyremainder'
    ];
}
