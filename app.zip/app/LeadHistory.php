<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeadHistory extends Model
{
    //


    protected $table = 'leadhistory';
    protected $fillable = [
        'courseid','leadid','course','calldate','description','nextfollow','time','addedby',
        
    ];
}
