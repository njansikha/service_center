<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Partners extends Model
{
    //



    protected $table = 'partners';
    protected $fillable = [
        'companyname','contactperson','designation','phonenumber','email','webaddress',
        'address','addedby','editedby'
    ];
}

