<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeePayment extends Model
{
    //

    protected $table = 'feepayment';
    protected $fillable = [
        'leadid','studentid','paidamount','instno','paymentmodes','nextdue',
        'review','paiddate','editedby','addedby','balance'
    ];
}
