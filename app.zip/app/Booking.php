<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    //

    protected $table = 'bookings';
    protected $fillable = [
        'service','slotdate','slottime','splace','contactnumber','details',
        'userid','servicecenterid'
    ];
}
