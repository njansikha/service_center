<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leads extends Model
{
    //

    protected $table = 'leads';
    protected $fillable = [
        'firstname','lastname','course','gender','email','phonenumber','whatsappnumber','assignedto',
        'address','city','state','pincode', 'leadsource','tags','pipelinestatus','description',
        'addedby','editedby','nextfollowup','project','contactperson','designation','gstno','leadtype','brand','productvalue'
    ];
}
