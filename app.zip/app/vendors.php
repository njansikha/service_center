<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vendors extends Model
{
    //

    protected $table = 'vendors';
    protected $fillable = [
        'name','product','brand','state','district','address','contactperson','designation','email','phonenumber','bankdetails','remark',
        'addedby','editedby','time'
    ];
}
