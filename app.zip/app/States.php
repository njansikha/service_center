<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class States extends Model
{
    //

    protected $table = 'states';
    protected $fillable = [
        'state','statecode'
    ];
}
