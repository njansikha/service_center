<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductMargin extends Model
{
    //
    protected $table = 'productmargin';
    protected $fillable = [
        'customertype','percentage',
    ];


}
