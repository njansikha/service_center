<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    //
    protected $table = 'bill';
    protected $fillable = [
        'bookingid','item1','item2','item3','item4','item5',
        'amount1','amount2','amount3','amount4','amount5','total'
    ];
}
