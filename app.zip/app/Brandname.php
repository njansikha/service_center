<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brandname extends Model
{
    //
    protected $table = 'brandname';
    protected $fillable = [
        'brandname',
    ];
}
