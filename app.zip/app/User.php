<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'designation', 'area_of_operation', 'mobile_number','mobile_number1','access_report','access_stafflisting',
        'access_addstudents','access_studentlisting','usertype','year','addedby','added_time','edited_time','added_date','edited_date',
        'description','access_create_course','access_create_class','access_leads','state','city','district','map','landmark','whrs','gstno',
        'address','logo','starttime','endtime','sunday','moday','tuesday','wednesday','thursday','friday', 'saturday',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
