<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Students extends Model
{
    //
    
    protected $table = 'students';
    protected $fillable = [
        'lid','photo_upload','govt_id','qualification_certi','college','resume',
        'courseid','batchno','batchstart','batchend','batchtime','classtype','coursefees','discount','paymentmode','installments',
        'advancepaid','duedate','paymentstatus','project','contactperson','designation','gstno','description','service'
    ];
}
