<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Redirect;
use DB;
use View;
use Session;
use Auth;
use File;
use App\User;
use App\States;
use App\AreaopOf;
use App\Districts;
use App\City;
use App\Usertype;
use App\PayModel;
use App\LeadSource;
use App\LeadTag;
use App\Pipelinemethod;
use App\CompanyProfile;
use App\Course;
use App\Leads;
use App\Classtype;
use App\LeadHistory;
use App\Batch;
use App\Students;
use App\Staffs;
use App\Partners;
use App\FeePayment;
use App\Product;
use App\Brandname;
use App\vendors;
use App\ProductMargin;
use App\ProductWiseMargin;
use App\ProductType;
use App\Booking;
use App\Bill;
use App\ContactUs;





use Dotenv\Result\Success;
use NunoMaduro\Collision\Adapters\Phpunit\State;

class AdminDataController extends Controller
{
    //
    public function users()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $users = User::orderBy('id', 'desc')
                ->get();
            //    print_r($users);

            return view('dashboard.users')->with('users', $users);
        }
    }
    public function edit_user(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $users = User::where('id', $req->userid)
                ->get();
            $aop = AreaopOf::where('status', '1')
                ->get();
            $utype = Usertype::where('status', '1')
                ->get();

            return view('dashboard.edituser')->with('users', $users)->with('aop', $aop)->with('utype', $utype);
        }
    }



    public function userchecking(Request $req)
    {
        $uid = User::where('email', $req->email)
            ->value('id');

        // echo $uid;
        //     return uid;

        // //    return view('dashboard.edituser')->with('users',$users);
        return json_encode($uid);
    }
    public function phonecheck(Request $req)
    {
        $uid = User::where('mobile_number', $req->phone)
            ->value('id');

        // echo $uid;
        // return ;

        return json_encode($uid);
        //    return view('dashboard.edituser')->with('users',$users);


    }

    public function deleteuser(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('users')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;
        }
    }





    public function StatePage()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $states = States::orderBy('id', 'desc')
                ->get();

            // return Success;

            return view('state.statepage')->with('states', $states);
        }
    }
    public function addstates(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {
            return redirect('/');
        } else {
            States::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('states')->where('id', $lastid)->update(['status' => '1']);
            $states = States::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();

            // //   print_r($states);

            $msg = "State added Succesfully";

            return redirect('/Statepage');
        }
    }

    public function edit_state(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $states = States::where('id', $req->userid)
                ->get();

            // return Success;

            return view('state.editstate')->with('states', $states);
        }
    }

    public function updatestate(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $e_statename = $req->input('e_statename');
            $e_statecode = $req->input('e_statecode');
            $values = array('state' => $e_statename, 'statecode' => $e_statecode);

            DB::table('states')
                ->where('id', $e_stateid)
                ->update($values);

            $states = States::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();
            $msg = 'Updated Succesfully';

            return redirect('/Statepage')->withErrors(['State Details Updated Successfully!!']);
        }
    }



    public function stateenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            States::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function statedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            States::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }

    public function delete_state(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $did = DB::table('states')->where(['id' => $req->userid])->delete();

            return json_encode($did);
        }
    }


    public function Districtpage()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $district = Districts::orderBy('id', 'desc')
                ->get();

            // return Success;

            return view('district.districtpage')->with('district', $district);
        }
    }

    public function adddistrict(Request $req)
    {
        // $this->uservalidation($req);
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            Districts::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('districts')->where('id', $lastid)->update(['status' => '1']);
            $district = Districts::orderBy('id', 'desc')
                ->get();

            // //   print_r($states);

            $msg = "State added Succesfully";

            return redirect('/Districtpage');
        }
    }



    public function districtenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Districts::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function districtdisable(Request $req)
    {
        $stateid = $req->input('stateid');
        $status = $req->input('status');





        Districts::whereId($stateid)->update(['status' => '1']);


        return 'Success';
    }

    public function edit_district(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $districts = Districts::where('id', $req->userid)
                ->get();
            $states = States::where('status', '1')
                ->get();

            // return Success;

            return view('district.edit_district')->with('states', $states)->with('districts', $districts);
        }
    }


    public function update_district(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('state');
            $district = $req->input('district');
            $values = array('state' => $state, 'district' => $district);

            DB::table('districts')
                ->where('id', $e_stateid)
                ->update($values);

            $states = Districts::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();
            $msg = 'Updated Succesfully';

            return redirect('/Districtpage')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function delete_district(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $did = DB::table('districts')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }


    public function Citypage()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $city = City::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('city.city')->with('city', $city);
        }
    }


    public function addcity(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            City::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('city')->where('id', $lastid)->update(['status' => '1']);
            $district = City::orderBy('id', 'desc')
                ->get();



            return redirect('/City');
        }
    }

    public function edit_city(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $City = City::where('id', $req->userid)
                ->get();

            $states = States::where('status', '1')
                ->get();
            $districts = Districts::where('status', '1')
                ->get();

            // return Success;

            return view('city.edit_city')->with('city', $City)->with('districts', $districts)->with('states', $states);
        }
    }


    public function update_city(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('state');
            $district = $req->input('district');
            $city = $req->input('city');
            $values = array('state' => $state, 'district' => $district, 'city' => $city);

            DB::table('city')
                ->where('id', $e_stateid)
                ->update($values);

            $states = City::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();


            return redirect('/City')->withErrors(['State Details Updated Successfully!!']);
        }
    }


    public function delete_city(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $did = DB::table('city')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }


    public function cityenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            City::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function citydisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            City::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }



    public function Usertype()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = Usertype::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('usertype.usertype')->with('usertype', $usertype);
        }
    }

    public function addusertype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            // $this->uservalidation($req);


            Usertype::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('usertype')->where('id', $lastid)->update(['status' => '1']);
            $states = Usertype::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();

            // //   print_r($states);

            $msg = "State added Succesfully";

            return redirect('/Usertype');
        }
    }


    public function edit_usertype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $usertype = Usertype::where('id', $req->userid)
                ->get();



            // return Success;

            return view('usertype.edit_usertype')->with('usertype', $usertype);
        }
    }

    public function update_usertype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('usertype');
            $masterdata = $req->input('masterdata');
            $lead = $req->input('lead');
            $product = $req->input('product');
            $staff = $req->input('staff');
            $district = $req->input('district');
            $city = $req->input('city');
            $values = array('usertype' => $state, 'masterdata' => $masterdata, 'lead' => $lead, 'staff' => $staff, 'product' => $product);

            DB::table('usertype')
                ->where('id', $e_stateid)
                ->update($values);

            $states = Usertype::where('status', '1')
                ->orderBy('id', 'desc')
                ->get();


            return redirect('/Usertype')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function delete_usertype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $did = DB::table('usertype')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function usertypeenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Usertype::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function usertypedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Usertype::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }

    public function Area()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $area = AreaopOf::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('area.areaof')->with('usertype', $area);
        }
    }
    public function addarea(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            AreaopOf::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('areaof')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Area');
        }
    }

    public function delete_area(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('areaof')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }
    public function edit_area(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = AreaopOf::where('id', $req->userid)
                ->get();



            // return Success;

            return view('area.edit_areaof')->with('usertype', $usertype);
        }
    }


    public function update_areaof(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('area' => $state);

            DB::table('areaof')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Area')->withErrors(['State Details Updated Successfully!!']);
        }
    }


    public function areaenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            AreaopOf::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function areadisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            AreaopOf::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function Paymentmodes()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $paym = PayModel::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('payment.paymentmode')->with('usertype', $paym);
        }
    }
    public function addpaymentmethod(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            // $this->uservalidation($req);


            PayModel::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('paymentmethod')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Paymentmodes');
        }
    }
    public function delete_paymentmode(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('paymentmethod')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function edit_payment(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = PayModel::where('id', $req->userid)
                ->get();



            // return Success;

            return view('payment.edit_paymentmode')->with('usertype', $usertype);
        }
    }


    public function update_payment(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('paymentmethod' => $state);

            DB::table('paymentmethod')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Paymentmodes')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function paymentenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            PayModel::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function paymentdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            PayModel::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }





    public function Leadsource()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $paym = Leadsource::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('Leadsource.Leadsource')->with('usertype', $paym);
        }
    }
    public function addLeadsource(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            // $this->uservalidation($req);


            Leadsource::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('leadsource')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Leadsource');
        }
    }
    public function delete_Leadsource(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('leadsource')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function edit_Leadsource(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $usertype = Leadsource::where('id', $req->userid)
                ->get();



            // return Success;

            return view('Leadsource.edit_Leadsource')->with('usertype', $usertype);
        }
    }


    public function update_Leadsource(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('leadsource' => $state);

            DB::table('leadsource')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Leadsource')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function Leadsourceenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Leadsource::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function Leadsourcedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Leadsource::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }




    public function Leadtag()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $paym = LeadTag::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('Leadtag.Leadtag')->with('usertype', $paym);
        }
    }
    public function addLeadtag(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            LeadTag::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('leadtag')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Leadtag');
        }
    }
    public function delete_Leadtag(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('leadtag')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function edit_Leadtag(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = LeadTag::where('id', $req->userid)
                ->get();



            // return Success;

            return view('Leadtag.edit_Leadtag')->with('usertype', $usertype);
        }
    }


    public function update_Leadtag(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('leadtag' => $state);

            DB::table('leadtag')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Leadtag')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function Leadtagenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            LeadTag::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function Leadtagdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            LeadTag::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function Pipelinemethod()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $paym = Pipelinemethod::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('Pipelinemethod.Pipelinemethod')->with('usertype', $paym);
        }
    }
    public function addPipelinemethod(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            Pipelinemethod::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('pipelinemethod')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Pipelinemethod');
        }
    }
    public function delete_Pipelinemethod(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('pipelinemethod')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function edit_Pipelinemethod(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = Pipelinemethod::where('id', $req->userid)
                ->get();



            // return Success;

            return view('Pipelinemethod.edit_Pipelinemethod')->with('usertype', $usertype);
        }
    }

    public function update_Pipelinemethod(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('pipelinemethod' => $state);

            DB::table('Pipelinemethod')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Pipelinemethod')->withErrors(['State Details Updated Successfully!!']);
        }
    }

    public function Pipelinemethodenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Pipelinemethod::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function Pipelinemethoddisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Pipelinemethod::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function districtlist(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $disricts = Districts::where('state', $req->stateid)
                ->pluck("district", "id");
            // print_r($disricts);


            // return Success;
            $data = view('District.districtdropdown', compact('disricts'))->render();
            return response()->json(['options' => $data]);
        }
    }



    public function SystemSettings(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = CompanyProfile::where('id', '1')
                ->get();


            return view('systemsettings.systemsettings')->with('companydetails', $usertype);
        }
    }

    public function systemregistration(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            CompanyProfile::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('companyprofile')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/SystemSettings');
        }
    }


    public function edit_systemsettings(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = CompanyProfile::where('id', $req->userid)
                ->get();



            // return Success;

            return view('systemsettings.edit_systemsettings')->with('usertype', $usertype);
        }
    }



    public function systemedit(Request $req)
    {




        $tbid = $req->input('tbid');
        $compayname = $req->input('compayname');
        $contactnumber = $req->input('contactnumber');
        $emailid = $req->input('emailid');

        $Address = $req->input('Address');
        $logothumb = $req->file('logothumb');
        $workinghours = $req->input('workinghours');
        $starttime = $req->input('starttime');
        $endtime = $req->input('endtime');
        $sunday = $req->input('sunday');
        $monday = $req->input('monday');
        $tuesday = $req->input('tuesday');
        $wednesday = $req->input('wednesday');
        $thursday = $req->input('thursday');
        $friday = $req->input('friday');
        $saturday = $req->input('saturday');
        $shortcode = $req->input('shortcode');
        $gstno = $req->input('gstno');
        $editedby = $req->input('editedby');;


        if ($logothumb != '') {

            $destinationPath = 'upload/companyprofile/';
            $fileName = $logothumb->getClientOriginalName();
            $newfilename = $destinationPath . $fileName;
            $logothumb->move($destinationPath, $fileName);
        } else {

            $newfilename = $req->input('oldlogo');
        }


        $values = array(
            'compayname' => $compayname, 'contactnumber' => $contactnumber, 'emailid' => $emailid, 'Address' => $Address,
            'workinghours' => $workinghours, 'starttime' => $starttime, 'endtime' => $endtime,
            'sunday' => $sunday, 'monday' => $monday, 'tuesday' => $tuesday,
            'wednesday' => $wednesday, 'thursday' => $thursday, 'friday' => $friday,
            'saturday' => $saturday, 'saturday' => $saturday,
            'gstno' => $gstno, 'editedby' => $editedby, 'logoactual' => $newfilename
        );




        DB::table('companyprofile')
            ->where('id', $tbid)
            ->update($values);
        return redirect('/SystemSettings')->withErrors(['User Details Updated Successfully!!']);
    }



    public function product()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $paym = Product::orderBy('id', 'desc')
                ->paginate(10);

                $brand = Brandname::orderBy('id', 'desc')
                ->get();
                $vendors = vendors::orderBy('id', 'desc')
                ->get();
            // return Success;

            return view('product.product')->with('courses', $paym)->with('brand', $brand)->with('vendors', $vendors);
        }
    }

    public function newproduct(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $productname = $req->input('productname');
            Product::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
            $productprice = $req->input('price');
            $landing_expense = $req->input('landing_expense');
          


            DB::table('product')->where('id', $lastid)->update(['status' => '1']);
            
            $productmargin = ProductMargin::where('status', '1')->pluck('customertype','percentage');
           foreach($productmargin as $key=>$value)
           {
           
         
               $totalamt = $productprice + ( $productprice * ( $key/100 ) ) + $landing_expense;
            //    echo $totalamt;
            //    exit;
               
               DB::table('productwisemargin')->insert(
                ['margintype' => $value, 'amount' => $totalamt, 'productid' => $lastid]
            );

           }
        
// exit;
 

            DB::table('donutchart')->insert(
                ['label' => $productname, 'value' => '0', 'courseid' => $lastid]
            );

            // //   print_r($states);

            $msg = "Product added Succesfully";

            return redirect('/product');
        }
    }


    public function edit_product(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = Product::where('id', $req->userid)
                ->get();



            // return Success;

            return view('product.editproduct')->with('usertype', $usertype);
        }
    }


    public function delete_product(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('product')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }
    public function update_product(Request $req)
    {




        $tbid = $req->input('tbid');
        $productname = $req->input('productname');
        $specification = $req->input('specification');
        $modelnumber = $req->input('modelnumber');

        $price = $req->input('price');

        $landing_expense = $req->input('landing_expense');
        $vendorname = $req->input('vendorname');
        $warentyremainder = $req->input('warentyremainder');
        $Eligibility = $req->input('Eligibility');
        $description = $req->input('description');




        $values = array(
            'productname' => $productname, 'specification' => $specification, 'modelnumber' => $modelnumber, 'price' => $price,
            'landing_expense' => $landing_expense, 'vendorname' => $vendorname, 'warentyremainder' => $warentyremainder,

        );




        DB::table('product')
            ->where('id', $tbid)
            ->update($values);


            $productmargin = ProductMargin::where('status', '1')->pluck('customertype','percentage');
            foreach($productmargin as $key=>$value)
            {
            
          
                $totalamt = $price  + ( $price  * ( $key/100 ) ) + $landing_expense;
             //    echo $totalamt;
             //    exit;

          $txid=   DB::table('productwisemargin')->where('margintype',$value)->where('productid',$tbid )->value('id');
          if($txid !='')
          {
            DB::table('productwisemargin')->where('id',$txid)->update(
                ['margintype' => $value, 'amount' => $totalamt, 'productid' => $txid]
            );
          }
          else{
            DB::table('productwisemargin')->insert(
                ['margintype' => $value, 'amount' => $totalamt, 'productid' => $txid]
            );
          }
                
              
 
            }
        return redirect('/product')->withErrors(['Product Details Updated Successfully!!']);
    }





    public function productenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Product::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function productdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Product::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function classtype()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $paym = Classtype::orderBy('id', 'desc')
                ->get();


            // return Success;

            return view('classtype.classtype')->with('classtype', $paym);
        }
    }


    public function addclasstype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            Classtype::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('classtype')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/Class-Type');
        }
    }


    public function edit_classtype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = Classtype::where('id', $req->userid)
                ->get();



            // return Success;

            return view('classtype.edit_classtype')->with('usertype', $usertype);
        }
    }


    public function update_classtype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('area');

            $values = array('classtype' => $state);

            DB::table('classtype')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/Class-Type')->withErrors(['Class Type Updated Successfully!!']);
        }
    }


    public function delete_classtype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('classtype')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }


    public function classtypeenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Classtype::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function classtypedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Classtype::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }



    public function leads()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $utype = Auth::user()->usertype;
            $usid = Auth::user()->id;
            if ($utype == 'Admin') {
                $data['leads'] = Leads::orderBy('id', 'desc')->where('pipelinestatus', '!=', '4')
                    ->get();
            } else {
                $data['leads'] = Leads::orderBy('id', 'desc')->where('assignedto', $usid)->where('pipelinestatus', '!=', '4')
                    ->get();
            }
            $data['tags'] = LeadTag::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['pipeline'] = Pipelinemethod::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['source'] = LeadSource::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['course'] = Course::where('status', '1')
                ->get();
            $data['city'] = City::where('status', '1')
                ->get();
            $data['users'] = User::where('status', '1')->where('usertype', 'Telecaller')
                ->get();
            $data['product'] = Product::where('status', '1')
                ->get();
                $data['brand'] = Brandname::where('status', '1')
                ->get();
                $data['productmargin'] = ProductMargin::where('status', '1')
                ->get();



            // echo "<pre>";
            // print_r($data['course']);
            // echo "</pre>";

            return view('leads.leads', $data);
        }
    }



    public function newleads(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);



            $course = $req->input('course');
            $nextfollowup = $req->input('nextfollowup');
            $assignedto = $req->input('assignedto');
            $description = $req->input('description');
            $time = $req->input('time');
            $addedby = $req->input('addedby');
            Leads::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
            $calldate = date('d/m/Y');







            DB::table('leads')->where('id', $lastid)->update(['status' => '1']);

            $data = array('course' => $course, "nextfollow" => $nextfollowup, "calldate" => $calldate, "assignedto" => $assignedto, "description" => $description, "leadid" => $lastid, "status" => '0', "addedby" => $addedby, 'time' => $time);
            DB::table('leadhistory')->insert($data);


            return redirect('/leads');
        }
    }

    public function leadsenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Leads::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function leadsdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Leads::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }

    public function edit_leads(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $data['usertype'] = Leads::where('id', $req->userid)
                ->get();
            $data['leads'] = Leads::orderBy('id', 'desc')
                ->get();
            $data['tags'] = LeadTag::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['pipeline'] = Pipelinemethod::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['source'] = LeadSource::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['course'] = Product::where('status', '1')
                ->get();
            $data['city'] = City::where('status', '1')
                ->get();
            $data['users'] = User::where('status', '1')->where('usertype', 'Telecaller')
                ->get();




            // return Success;

            return view('leads.edit_leads', $data);
        }
    }


    public function updateleads(Request $req)
    {




        $tbid = $req->input('id');


        Leads::whereId($tbid)->update($req->except(['_token']));


        return redirect('/leads')->withErrors(['Lead Details Updated Successfully!!']);
    }


    public function delete_lead(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('leads')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function leadprofile($id)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $data['leads'] = Leads::where('id', $id)
                ->get();
            $data['tags'] = LeadTag::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['pipeline'] = Pipelinemethod::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['source'] = LeadSource::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['course'] = Course::where('status', '1')
                ->get();
            $data['city'] = City::where('status', '1')
                ->get();
            $data['users'] = User::where('status', '1')->where('usertype', 'Telecaller')
                ->get();
            $data['history'] = LeadHistory::where('leadid', $id)->orderBy('nextfollow', 'desc')
                ->get();
            // print_r($data['user']);
            // exit;





            return view('leads.leadprofile', $data);
        }
    }




    public function leadsgrid()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $data['leads'] = Leads::orderBy('id', 'desc')
                ->get();
            $data['tags'] = LeadTag::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['pipeline'] = Pipelinemethod::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['source'] = LeadSource::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['course'] = Course::where('status', '1')
                ->get();
            $data['city'] = City::where('status', '1')
                ->get();
            $data['users'] = User::where('status', '1')->where('usertype', 'Telecaller')
                ->get();





            return view('leads.leadgrid', $data);
        }
    }



    public function addnotes(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);



            $course = $req->input('course');
            $calldate = $req->input('calldate');
            $nextfollowup = $req->input('nextfollowup');
            $assignedto = $req->input('assignedto');
            $description = $req->input('description');
            $time = $req->input('time');
            $addedby = $req->input('addedby');
            $lastid = $req->input('leadid');
            $pipeline = $req->input('pipeline');
            $tagsname = $req->input('tagsname');
            $fees = $req->input('afees');
            $pfees = $req->input('pfees');
            // echo  $description;
            // exit;





            $laid = LeadHistory::where('leadid', $lastid)->max('id');

            DB::table('leadhistory')->where('id', $laid)->update(['status' => '1']);



            $data = array('course' => $course, "nextfollow" => $nextfollowup, "fees" => $fees, "discountgiven" => $pfees, "calldate" => $calldate, "assignedto" => $assignedto, "description" => $description, "leadid" => $lastid, "status" => '0', "addedby" => $addedby, 'time' => $time);
            DB::table('leadhistory')->insert($data);

            $data1 = array('pipelinestatus' => $pipeline, "tags" => $tagsname, "editedby" => $addedby);
            DB::table('leads')->where('id', $lastid)->update($data1);


            return redirect('/leadprofile/' . $lastid);
        }
    }


    public function get_followdate(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            //   $did = DB::table('leadhistory')->where(['leadid' => $req->userid])->max('id');
            //   $nextday = DB::table('leadhistory')->where(['id' => $did])->value('nextfollow');


            //   $daten = strtotime("+2 day", $nextday);
            //   echo $daten;
            //   exit;
            // return json_encode($nextday);
            $pipelinemethod = Pipelinemethod::where('status', '1')->get();
            $tags = LeadTag::where('status', '1')->get();

            return view('leads.leadpipeline')->with('pipelinemethod', $pipelinemethod)->with('tags', $tags)->with('currentuser', $req->userid);
        }
    }



    public function change_assigned_user(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $assignedusers = User::where('status', '1')
                ->get();
            $currentuser = $req->curntuserid;






            return view('leads.leadasignedto')->with('assignedusers', $assignedusers)->with('currentuser', $currentuser);
        }
    }



    public function change_assigned_username(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {




            $lastid = $req->input('leadnid');
            $oldassignedto = $req->input('oldassignedto');
            $newassigned = $req->input('newassigned');
            $changedate = $req->input('changedate');

            $lastlead = DB::table('leadhistory')->where('leadid', $lastid)->max('id');
            $stat = DB::table('leadhistory')->where('id', $lastlead)->value('status');
            // echo $stat;
            // exit;
            if ($stat == '0') {
                DB::table('leadhistory')->where('id', $lastlead)->update(['assignedto' => $newassigned]);
            }



            // echo $lastid;
            // exit;


            DB::table('leads')->where('id', $lastid)->update(['oldassignedto' => $oldassignedto, 'assignedto' => $newassigned, 'user_changed' => $changedate]);



            return redirect('/leads');
        }
    }


    public function converttostudent(Request $req)
    {


        $data['leads'] = Leads::orderBy('id', 'desc')->where('id', $req->userid)
            ->get();
        $courseid = Leads::where('id', $req->userid)
            ->value('course');


        $data['course'] = Course::where('status', '1')
            ->get();
        $data['coursemd'] = Course::where('id', $courseid)
            ->get();


        $data['batch'] = Batch::where('status', '1')
            ->get();

        return view('leads.leadtostud', $data)->with('lid', $req->userid);
    }





    public function batch()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {



            $data['batch'] = Batch::orderBy('id', 'desc')
                ->get();


            return view('batch.batch', $data);
        }
    }


    public function addbatch(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            Batch::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('batch')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/batch');
        }
    }


    public function batchenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Batch::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function batchdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Batch::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function edit_batch(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $batch = Batch::where('id', $req->userid)
                ->get();



            // return Success;

            return view('batch.edit_batch')->with('batch', $batch);
        }
    }


    public function updatebatch(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $classtype = $req->input('classtype');
            $batchname = $req->input('batchname');
            $batchno = $req->input('batchno');
            $batchtiming = $req->input('batchtiming');
            $startday = $req->input('startday');
            $endday = $req->input('endday');
            $editedby = $req->input('addedby');
            $tblid = $req->input('tblid');
            $values = array(
                'classtype' => $classtype, 'batchname' => $batchname, 'batchno' => $batchno,
                'batchtiming' => $batchtiming, 'startday' => $startday, 'endday' => $endday, 'editedby' => $editedby
            );

            DB::table('batch')
                ->where('id', $tblid)
                ->update($values);




            return redirect('/batch')->withErrors(['Batch Updated Successfully!!']);
        }
    }

    public function delete_batch(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('batch')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }





    public function batch_details(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('batch')->where(['id' => $req->userid])->get();
            $classtype = Classtype::where('status', '1')->get();


            return view('batch.batchdata')->with('batch', $did)->with('classtype', $classtype);
        }
    }

    public function batch_course(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $course = DB::table('course')->where(['id' => $req->userid])->get();



            return view('batch.coursedata')->with('coursems', $course);
        }
    }


    public function leadtostudent(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);

            $lid = $req->input('uid');
            $courseid = $req->input('courseid');
            $photo_upload = $req->file('photo_upload');

            $destinationPath = 'upload/students/photo';
            $fileName = $photo_upload->getClientOriginalName();
            $newfilename = $destinationPath . $fileName;
            $photo_upload->move($destinationPath, $fileName);

            $govt_id = $req->file('govt_id');

            $destinationPath = 'upload/students/idproof';
            $fileName1 = $govt_id->getClientOriginalName();
            $newfilename1 = $destinationPath . $fileName1;
            $govt_id->move($destinationPath, $fileName1);

            $qualification_certi = $req->file('qualification_certi');

            $destinationPath = 'upload/students/cerificate';
            $fileName2 = $qualification_certi->getClientOriginalName();
            $newfilename2 = $destinationPath . $fileName2;
            $qualification_certi->move($destinationPath, $fileName2);

            $resume = $req->file('resume');

            $destinationPath = 'upload/students/resume';
            $fileName3 = $resume->getClientOriginalName();
            $newfilename3 = $destinationPath . $fileName3;
            $resume->move($destinationPath, $fileName3);



            Students::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('students')->where('id', $lastid)->update([
                'status' => '1', 'lid' => $lid, 'govt_id' => $newfilename1,
                'qualification_certi' => $newfilename2, 'photo_upload' => $newfilename, 'resume' => $newfilename3
            ]);
            DB::table('leads')->where('id', $lid)->update(['pipelinestatus' => '4']);
            $maxleadid = DB::table('leadhistory')->where('leadid', $lid)->max('id');
            DB::table('leadhistory')->where('id', $maxleadid)->update(['status' => '1']);
            $cnt = DB::table('donutchart')->where('courseid', $courseid)->value('value');

            $newcnt = $cnt + 1;
            DB::table('donutchart')->where('courseid', $courseid)->update(['value' => $newcnt]);


            //   echo   $newcnt;
            //   exit;

            return redirect('/students');
        }
    }



    public function students()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);

            $students = DB::table('leads')
                ->select('leads.firstname', 'leads.lastname', 'leads.phonenumber', 'leads.email', 'students.*')
                ->join('students', 'leads.id', '=', 'students.lid')

                ->get();


            return view('students.students')->with('students', $students);
        }
    }


    public function add_batch_faculity(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            $bacthid = $req->userid;

            return view('batch.addfculity')->with('batchid', $bacthid);
        }
    }

    public function addfaculity(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $tableid = $req->input('tableid');
            $faculity = $req->input('faculity');

            $addedby = $req->input('addedby');

            $values = array('faculity' => $faculity, 'editedby' => $addedby);

            DB::table('batch')
                ->where('id', $tableid)
                ->update($values);




            return redirect('/batch')->withErrors(['Batch Updated Successfully!!']);
        }
    }



    public function studentenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Students::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function studentdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Students::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }



    public function edit_students(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $students = Students::where('id', $req->userid)
                ->get();
            $leadid = Students::where('id', $req->userid)
                ->value('lid');
            $leads = Leads::where('id', $leadid)
                ->get();
            $course = Product::where('status', '1')
                ->get();
            $batch = Batch::where('status', '1')
                ->get();
            $city = City::where('status', '1')
                ->get();
            $state = States::where('status', '1')
                ->get();



            // return Success;

            return view('students.edit_student')->with('students', $students)->with('leads', $leads)
                ->with('course', $course)->with('batch', $batch)->with('city', $city)->with('state', $state);
        }
    }


    public function delete_student(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $lid = DB::table('students')->where(['id' => $req->userid])->value('lid');
            $did = DB::table('students')->where(['id' => $req->userid])->delete();
            $did = DB::table('leads')->where(['id' => $lid])->delete();

            return json_encode($did);

            // return Success;

        }
    }

    public function staffs()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $staffs = Staffs::orderBy('id', 'desc')->where('addedby',Auth::user()->id)
                ->get();


            // return Success;

            return view('staffs.staffs')->with('course', $staffs);
        }
    }



    public function newstaff(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {
            return redirect('/');
        } else {
            Staffs::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('staffstb')->where('id', $lastid)->update(['status' => '1']);


            // //   print_r($states);

            $msg = "Staff added Succesfully";

            return redirect('/staffs');
        }
    }



    public function staffenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Staffs::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function staffdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Staffs::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function delete_staff(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('staffstb')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }


    public function edit_staff(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $batch = Staffs::where('id', $req->userid)
                ->get();



            // return Success;

            return view('staffs.edit_staff')->with('batch', $batch);
        }
    }


    public function edit_student_data(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);

            $lid = $req->input('uid');
            $stdid = $req->input('stdid');
            $photo_upload = $req->file('photo_upload');
            if ($photo_upload != '') {
                $destinationPath = 'upload/students/photo';
                $fileName = $photo_upload->getClientOriginalName();
                $newfilename = $destinationPath . $fileName;
                $photo_upload->move($destinationPath, $fileName);
            } else {
                $newfilename = $req->file('oldphoto');
            }



            $govt_id = $req->file('govt_id');

            if ($govt_id != '') {

                $destinationPath = 'upload/students/idproof';
                $fileName1 = $govt_id->getClientOriginalName();
                $newfilename1 = $destinationPath . $fileName1;
                $govt_id->move($destinationPath, $fileName1);
            } else {
                $newfilename1 = $req->input('oldgovt_id');
            }

            $qualification_certi = $req->file('qualification_certi');
            if ($qualification_certi != '') {


                $destinationPath = 'upload/students/cerificate';
                $fileName2 = $qualification_certi->getClientOriginalName();
                $newfilename2 = $destinationPath . $fileName2;
                $qualification_certi->move($destinationPath, $fileName2);
            } else {
                $newfilename2 = $req->input('oldqualification_certi');
            }

            $resume = $req->input('resume');


            if ($resume != '') {

                $destinationPath = 'upload/students/resume';
                $fileName3 = $resume->getClientOriginalName();
                $newfilename3 = $destinationPath . $fileName3;
                $resume->move($destinationPath, $fileName3);
            } else {
                $newfilename3 = $req->input('oldresume');
            }



            $firstname = $req->input('firstname');
            $lastname = $req->input('lastname');
            $gender = $req->input('gender');
            $email = $req->input('email');
            $phonenumber = $req->input('phonenumber');
            $whatsappnumber = $req->input('whatsappnumber');
            $address = $req->input('address');
            $city = $req->input('city');
            $state = $req->input('state');
            $whatsappnumber = $req->input('whatsappnumber');
            $pincode = $req->input('pincode');
            $college = $req->input('college');
            $courseid = $req->input('courseid');
            $batchno = $req->input('batchno');

            $batchstart = $req->input('batchstart');
            $batchend = $req->input('batchend');
            $batchtime = $req->input('batchtime');
            $classtype = $req->input('classtype');
            $addedby = $req->input('addedby');


            DB::table('students')->where('id', $stdid)->update([
                'status' => '1',  'govt_id' => $newfilename1,
                'qualification_certi' => $newfilename2, 'photo_upload' => $newfilename, 'resume' => $newfilename3,
                'college' => $college, 'courseid' => $courseid, 'batchstart' => $batchstart,
                'batchend' => $batchend, 'batchtime' => $batchtime, 'classtype' => $classtype, 'editedby' => $addedby

            ]);

            DB::table('leads')->where('id', $lid)->update([
                'firstname' => $firstname, 'lastname' => $lastname,
                'gender' => $gender, 'email' => $email, 'phonenumber' => $phonenumber,
                'whatsappnumber' => $whatsappnumber, 'address' => $address, 'city' => $city,
                'state' => $state, 'pincode' => $pincode

            ]);




            return redirect('/students');
        }
    }






    public function edit_staffdata(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            $tableid = $req->input('tableid');


            $employeename = $req->input('employeename');
            $position = $req->input('position');
            $joinindate = $req->input('joinindate');
            $email = $req->input('email');
            $phonenumber = $req->input('phonenumber');

            $addedby = $req->input('addedby');


            DB::table('staffstb')->where('id', $tableid)->update([
                'employeename' => $employeename, 'position' => $position, 'joinindate' => $joinindate,
                'email' => $email, 'phonenumber' => $phonenumber, 'editedby' => $addedby

            ]);






            return redirect('/staffs');
        }
    }




    public function partners()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $states = Partners::orderBy('id', 'desc')
                ->get();

            // return Success;

            return view('partners.partners')->with('states', $states);
        }
    }

    public function newpartner(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {


            Partners::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('partners')->where('id', $lastid)->update(['status' => '0']);


            // //   print_r($states);

            $msg = "Partner Registered Succesfully";

            return redirect('/New-Partners');
        } else {
            Partners::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('partners')->where('id', $lastid)->update(['status' => '1']);





            return redirect('/partners')->withErrors(['Partner Registered Successfully!! Please Wait For Admin Approval']);
        }
    }


    public function edit_partner(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $states = Partners::where('id', $req->userid)
                ->get();

            // return Success;

            return view('partners.editpartners')->with('states', $states);
        }
    }

    public function edit_partnerdata(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $companyname = $req->input('companyname');
            $contactperson = $req->input('contactperson');
            $designation = $req->input('designation');
            $phonenumber = $req->input('phonenumber');
            $email = $req->input('email');
            $webaddress = $req->input('webaddress');
            $address = $req->input('address');
            $tableid = $req->input('tableid');
            $editedby = $req->input('addedby');

            $values = array(
                'companyname' => $companyname, 'contactperson' => $contactperson, 'designation' => $designation, 'phonenumber' => $phonenumber, 'email' => $email, 'webaddress' => $webaddress, 'address' => $address, 'editedby' => $editedby
            );

            DB::table('partners')
                ->where('id', $tableid)
                ->update($values);




            return redirect('/partners')->withErrors(['Partner Details Updated Successfully!!']);
        }
    }



    public function delete_partner(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $did = DB::table('partners')->where(['id' => $req->userid])->delete();

            return json_encode($did);
        }
    }

    public function partnerenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Partners::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function partnerdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Partners::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }



    public function fees_management(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            // $feesid = LeadHistory::where('leadid', $req->userid)
            // ->max('id');

            // $leadsdata = Leads::where('id', $req->userid)
            // ->get();
            // $fees_details = LeadHistory::where('id', $feesid)
            // ->get();
            $students = Students::where('id', $req->userid)
                ->value('id');
            $lid = Students::where('id', $req->userid)
                ->value('lid');
            $coursefees = Students::where('id', $req->userid)
                ->value('coursefees');
            $discount = Students::where('id', $req->userid)
                ->value('discount');
            $advancepaid = Students::where('id', $req->userid)
                ->value('advancepaid');
            $feehistory = FeePayment::where('studentid', $req->userid)
                ->get();







            return view('students.feesmanagement')->with('students', $students)
                ->with('leadid', $req->userid)->with('coursefees', $coursefees)->with('discount', $discount)->with('advancepaid', $advancepaid)
                ->with('feehistory', $feehistory);
        }
    }




    public function fees_updation(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {
            return redirect('/');
        } else {
            FeePayment::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('feepayment')->where('id', $lastid)->update(['status' => '1']);


            // //   print_r($states);

            $msg = "Fees added Succesfully";

            return redirect('/students');
        }
    }




    public function new_studentdr(Request $req)
    {
        // $this->uservalidation($req);

        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $courseid = $req->input('courseid');
            Leads::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
            DB::table('leads')->where('id', $lastid)->update(['status' => '1']);
            Students::create($req->all());
            $stdid = DB::getPdo()->lastInsertId();
            DB::table('students')->where('id', $stdid)->update(['status' => '1', 'lid' => $lastid]);
            //    $paymentmode = $req->input('paymentmode');
            //    $installments = $req->input('installments');
            //    $advancepaid = $req->input('advancepaid');
            //    $review = 'Advance Paid';
            //    $duedate = $req->input('duedate');
            //    $changedate = $req->input('changedate');

            //    DB::table('feepayment')->insert(['leadid' =>$lastid,'studentid'=>$stdid,'paidamount'=>$advancepaid,'instno'=>'0','paymentmodes'=>$paymentmode
            // ,'nextdue'=>$duedate,'review'=>$review,'paiddate'=> $changedate,'status'=>'1']);


            $cnt = DB::table('donutchart')->where('courseid', $courseid)->value('value');

            $newcnt = $cnt + 1;
            DB::table('donutchart')->where('courseid', $courseid)->update(['value' => $newcnt]);

            // //   print_r($states);

            $msg = "Lead added Succesfully";

            return redirect('/students');
        }
    }



    public function userenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            User::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function userdisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            User::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }



    public function location()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $states = States::orderBy('id', 'desc')
                ->get();
            $district = Districts::orderBy('id', 'desc')
                ->get();

            // return Success;



            return view('state.statepage')->with('states', $states)->with('district', $district);
        }
    }














    // Brandname


    public function brandname()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $paym = Brandname::orderBy('id', 'desc')
                ->paginate(10);


            // return Success;

            return view('brandname.brandname')->with('classtype', $paym);
        }
    }


    public function addbrandname(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);


            Brandname::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();

            DB::table('brandname')->where('id', $lastid)->update(['status' => '1']);


            return redirect('/brandname');
        }
    }


    public function edit_brandname(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $usertype = Brandname::where('id', $req->userid)
                ->get();



            // return Success;

            return view('brandname.edit_brandname')->with('usertype', $usertype);
        }
    }


    public function update_brandname(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $e_stateid = $req->input('e_stateid');
            $state = $req->input('brandname');

            $values = array('brandname' => $state);

            DB::table('brandname')
                ->where('id', $e_stateid)
                ->update($values);




            return redirect('/brandname')->withErrors(['Branname Updated Successfully!!']);
        }
    }


    public function delete_brandname(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $did = DB::table('brandname')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }


    public function brandnameenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Brandname::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function brandnamedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            Brandname::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }






    public function vendor()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $utype = Auth::user()->usertype;
            $usid = Auth::user()->id;

            $data['leads'] = vendors::orderBy('id', 'desc')
                ->paginate(10);



            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
                $data['city'] = City::where('status', '1')
                ->get();


            $data['product'] = Product::where('status', '1')
                ->get();
                $data['brand'] = Brandname::where('status', '1')
                ->get();



            

            return view('vendor.vendor', $data);
        }
    }



    public function addvendor(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);



          
            $time = $req->input('time');
            $addedby = $req->input('addedby');
            vendors::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
      
            DB::table('vendors')->where('id', $lastid)->update(['status' => '1']);
            return redirect('/vendor');
        }
    }

    public function vendorenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            vendors::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function vendordisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            vendors::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }

    public function edit_vendor(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $data['vendors'] = vendors::where('id', $req->userid)
                ->get();
          
           
           
          
            $data['state'] = States::where('status', '1')->orderBy('id', 'desc')
                ->get();
            $data['district'] = Districts::where('status', '1')
                ->get();
                $data['product'] = Product::where('status', '1')
                ->get();
                $data['brand'] = Brandname::where('status', '1')
                ->get();
           




            // return Success;

            return view('vendor.edit_vendor', $data);
        }
    }


    public function update_vendor(Request $req)
    {




        $tbid = $req->input('id');
        $name = $req->input('name');
// echo $tbid;
// exit;

        vendors::whereId($tbid)->update($req->except(['_token']));
        // vendors::whereId($tbid)->update(['name' => $name ]);


        return redirect('/vendor')->withErrors(['Vendor Details Updated Successfully!!']);
    }


    public function delete_vendor(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

         echo  $req->userid;
            $did = DB::table('vendors')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }





    public function productmargin()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $utype = Auth::user()->usertype;
            $usid = Auth::user()->id;

            $data['classtype'] = ProductMargin::orderBy('id', 'desc')
                ->paginate(10);



            



            

            return view('productmargin.productmargin', $data);
        }
    }



    public function addproductmargin(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);



          
            $time = $req->input('time');
            $addedby = $req->input('addedby');
            ProductMargin::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
      
            DB::table('productmargin')->where('id', $lastid)->update(['status' => '1']);
            return redirect('/product-margin');
        }
    }

    public function productmarginenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            ProductMargin::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function productmargindisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            ProductMargin::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }

    public function edit_productmargin(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $data['projectmargin'] = ProductMargin::where('id', $req->userid)
                ->get();
          
           
           
          
           




            // return Success;

            return view('productmargin.edit_productmargin', $data);
        }
    }


    public function update_productmargin(Request $req)
    {




        $tbid = $req->input('id');
        $name = $req->input('name');
// echo $tbid;
// exit;

        ProductMargin::whereId($tbid)->update($req->except(['_token']));
        // vendors::whereId($tbid)->update(['name' => $name ]);


        return redirect('/product-margin')->withErrors(['Product Margin Details Updated Successfully!!']);
    }


    public function delete_productmargin(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

         echo  $req->userid;
            $did = DB::table('productmargin')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }



    public function searchproduct(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

        $product=  $req->product;
        $brand=  $req->brand;
        $location=  $req->location;

         if( ($product =='') && ($brand =='') && ($location !=''))
         {

            $dis=Districts::where('district', $location )
            ->value('id');
            $vendorsdetails = DB::table('vendors')->where(['district' => $dis])->get();
         }
         elseif( ($product =='') && ($brand !='') && ($location ==''))
         {
            $vendorsdetails = DB::table('vendors')->where(['brand' => $brand])->get();
        } 
        elseif( ($product !='') && ($brand =='') && ($location ==''))
        {
           $vendorsdetails = DB::table('vendors')->where(['product' => $product])->get();
         } 
         elseif( ($product !='') && ($brand =='') && ($location !=''))
         {
            $dis=Districts::where('district', $location )
            ->value('id');
            $vendorsdetails = DB::table('vendors')->where(['product' => $product])->where(['district' => $dis])->get();
          } 
          elseif( ($product =='') && ($brand !='') && ($location !=''))
          {
             $dis=Districts::where('district', $location )
             ->value('id');
             $vendorsdetails = DB::table('vendors')->where(['brand' => $brand])->where(['district' => $dis])->get();
           } 
           elseif( ($product !='') && ($brand =='') && ($location ==''))
           {
              
              $vendorsdetails = DB::table('vendors')->where(['product' => $product])->get();
            } 
            elseif( ($product !='') && ($brand !='') && ($location ==''))
            {
               
               $vendorsdetails = DB::table('vendors')->where(['product' => $product])->where(['brand' => $brand])->get();
             }
             elseif( ($product !='') && ($brand !='') && ($location !=''))
            {
                $dis=Districts::where('district', $location )
             ->value('id');
               
               $vendorsdetails = DB::table('vendors')->where(['product' => $product])->where(['brand' => $brand])->where(['district' => $dis])->get();
             }
             else
             {
                $vendorsdetails = DB::table('vendors')->get();
             }
         
         
           
            
            
            
            return view('vendor.vendorsearch')->with('vendorsdetails', $vendorsdetails);

        }
    }


    public function productsmargincalc(Request $req)
    {
        $landing=  $req->stateid;
        $productprice=  $req->productprice;
       

       $projectmargin= ProductMargin::where('status', '1')
               ->get();
       return view('product.productmargindis')->with('projectmargin',  $projectmargin)->with('pamt',  $landing)->with('productprice',  $productprice);
    }

    public function getProductMargin(Request $req)
    {

        $productid=  $req->productid;
        $marginid=  $req->marginid;
        
      
       

       $customertype= ProductMargin::where('id',  $marginid)
               ->value('customertype');
    

               $margintypecost= DB::table('productwisemargin')->where('productid',  $productid)->where('margintype',  $customertype)
               ->value('amount');
   
            return json_encode($margintypecost);

      
    }

  public function  getProductMargins(Request $req)
  {

    $productid=  $req->productid;
    $marginid=  $req->marginid;
    
  
   

   $customertype= ProductMargin::where('id',  $marginid)
           ->value('customertype');


           $margintypecost= DB::table('productwisemargin')->where('productid',  $productid)->where('margintype',  $customertype)
           ->value('amount');

        return json_encode($margintypecost);
  }


  public function producttype()
  {
      if (Auth::check() == '') {
          return redirect('/');
      } else {

          $utype = Auth::user()->usertype;
          $usid = Auth::user()->id;

          $data['producttype'] = ProductType::orderBy('id', 'desc')
              ->paginate(10);



          



          

          return view('producttype.producttype', $data);
      }
  }

  public function addproducttype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {  // $this->uservalidation($req);



          
            $time = $req->input('time');
            $addedby = $req->input('addedby');
            ProductType::create($req->all());
            $lastid = DB::getPdo()->lastInsertId();
      
            DB::table('producttype')->where('id', $lastid)->update(['status' => '1']);
            return redirect('/product-type');
        }
    }

    public function edit_producttype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $data['project'] = ProductType::where('id', $req->userid)
                ->get();
          
           
           
          
           




            // return Success;

            return view('producttype.edit_producttype', $data);
        }
    }

    public function update_producttype(Request $req)
    {




        $tbid = $req->input('id');
        $name = $req->input('name');
// echo $tbid;
// exit;

        ProductType::whereId($tbid)->update($req->except(['_token']));
        // vendors::whereId($tbid)->update(['name' => $name ]);


        return redirect('/product-type')->withErrors(['Product Type  Updated Successfully!!']);
    }


    public function delete_producttype(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

         echo  $req->userid;
            $did = DB::table('producttype')->where(['id' => $req->userid])->delete();

            return json_encode($did);

            // return Success;

        }
    }



    public function producttypeenable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            ProductType::whereId($stateid)->update(['status' => '0']);


            return 'Success';
        }
    }
    public function producttypedisable(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $stateid = $req->input('stateid');
            $status = $req->input('status');





            ProductType::whereId($stateid)->update(['status' => '1']);


            return 'Success';
        }
    }


    public function getBrand()
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
            $producttype = ProductType::orderBy('id', 'desc')
                ->get();

            // return Success;

            return view('producttype.producttypebrand')->with('brand', $producttype);
        }
    }

    public function getModelNumber(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $productid = $req->input('productid');
            $brandname = $req->input('brandname');
            $modelnumbers= DB::table('product')->where('productid',  $productid)->where('brand',  $brandname)
            ->pluck('modelnumber');

            // return Success;

            return view('leads.modelnumber')->with('modelnumbers', $modelnumbers);
        }
    }


    public function productchangeedit(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $productid = $req->input('producttype');
         $producttype =   ProductType::whereId($productid)->value('producttype');
           $brandsinedit = DB::table('product')->where('productname',  $producttype)->pluck('brand');
            return view('leads.brandatedit')->with('brandsinedit', $brandsinedit);
        }
    }
    public function modelchangebyedit(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $brand = $req->input('brand');
            $productedit = $req->input('productedit');
         $producttype =   ProductType::whereId($productedit)->value('producttype');
           $modelnumbersn = DB::table('product')->where('productname',  $producttype)
           ->where('brand',  $brand)->pluck('modelnumber');
            return view('leads.modelnumberedit')->with('modelnumbersn', $modelnumbersn);
        }
    }


    public function sortbypipeline(Request $req)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {

            $pipelineid = $req->input('pipelineid');
            // $productedit = $req->input('productedit');
         $leads =   Leads::where('pipelinestatus',  $pipelineid)->get();
        //    $modelnumbersn = DB::table('product')->where('productname',  $producttype)
        //    ->where('brand',  $brand)->pluck('modelnumber');
            return view('leads.sortbypipeline')->with('leads',  $leads);
        }
    }

    public function productview($id)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
           
            $data['product'] = Product::where('status', '1')
                ->get();
            
            // print_r($data['user']);
            // exit;





            return view('product.productview', $data);
        }
    }

    public function vendorview($id)
    {
        if (Auth::check() == '') {
            return redirect('/');
        } else {
           
            $data['product'] = vendors::where('status', '1')
                ->get();
            
            // print_r($data['user']);
            // exit;





            return view('vendors.vendorview', $data);
        }

        
    }


    public function userindex()
    {
        $data['state'] = States::where('status', '1')
                ->get();
                $data['states'] = States::where('status', '1')
                ->get();
                $data['distrcit'] = Districts::where('status', '1')
                ->get();
                $data['distrcits'] = Districts::where('status', '1')
                ->get();
                $data['city'] = City::where('status', '1')
                ->get();
                $data['citys'] = City::where('status', '1')
                ->get();
       
                return view('mainpage.index', $data);



}

public function addservicecenter(Request $req)
{
    // $this->uservalidation($req);

    $pass = $req->input('password');
    $email = $req->input('email');

    $req['password'] = bcrypt($pass);
    $did =    User::create($req->all());
        $lastid = DB::getPdo()->lastInsertId();

        DB::table('users')->where('id', $lastid)->update(['status' => '1']);
      

        if($did != '')
        {

            if(Auth::attempt(['email' => $email, 'password' => $pass])){

                $utype=Auth::user()->usertype;

                return redirect('/index');
            }

        }
        else
        {
            return redirect('/web');
        }
    
}


public function addcustomer(Request $req)
{
    // $this->uservalidation($req);

    // echo "ha";
    // exit;

    $pass = $req->input('password');
    $email = $req->input('email');


    $req['password'] = bcrypt($pass);
  
      $did =  User::create($req->all());
        $lastid = DB::getPdo()->lastInsertId();

        DB::table('users')->where('id', $lastid)->update(['status' => '1']);

        if($did != '')
        {

            if(Auth::attempt(['email' => $email, 'password' => $pass])){

                $utype=Auth::user()->usertype;

                return redirect('/customerhome');
            }

        }
        else
        {
            return redirect('/web');
        }
      

     

      
    
}

public function editserviceCenter()
{
    $uid=Auth::user()->id;
    $data['users'] = User::where('status', '1')
    ->get();

   return view('dashboard.edit_profiles', $data);
      
}

public function edit_popup(Request $req)
{
    // $uid=Auth::user()->id;
    $data['users'] = User::where('id', $req->userid)
    ->get();
    $data['state'] = States::where('status', '1')
    ->get();
    $data['district'] = Districts::where('status', '1')
    ->get();
    $data['city'] = City::where('status', '1')
    ->get();

   return view('dashboard.edit_profilespage', $data);
      
}

public function districtload(Request $req)
{
    $statecode = States::where('id', $req->stateid)
    ->value('statecode');
    $data['district'] = Districts::where('state', $statecode)
    ->get();

return view('dashboard.districtlist', $data);

}


public function cityload(Request $req)
{
    $statecode = States::where('id', $req->stateid)
    ->value('statecode');
    $data['city'] = City::where('state', $statecode)->where('district',  $req->districtid)
    ->get();

return view('dashboard.citylist', $data);

}
public function searchcenter(Request $req)
{
    $data['servicecenter'] = User::where('state', $req->stateid)->where('district',  $req->districtid)->where('city',  $req->city)->where('usertype',  'Service Center')
    ->get();
    // $data['city'] = City::where('state', $statecode)->where('district',  $req->districtid)
    // ->get();

return view('dashboard.servicecenterlist', $data);

}

public function logintobook(Request $req)
{
    if(Auth::attempt(['email' => $req->email, 'password' => $req->password])){

    $service_center_id =   $req->serviceceterid;
    // echo $service_center_id;
    // exit;

    $producttype = ProductType::where('status', '1')
    ->get();
        // return redirect('/customerhome')->with('service_center_id', $service_center_id);
    return  view('mainpage.book_appoinment')->with('service_center_id',$service_center_id)->with('producttype',$producttype);

    }
    else
    {
        return redirect('/')->withErrors(['Ooops Something Wrong Happens!! Please try agian or Contact Admin!!']);
    }   


}

public function customerhome()
{
    $data['state'] = States::where('status', '1')
    ->get();
    $data['states'] = States::where('status', '1')
    ->get();
    $data['distrcit'] = Districts::where('status', '1')
    ->get();
    $data['distrcits'] = Districts::where('status', '1')
    ->get();
    $data['city'] = City::where('status', '1')
    ->get();
    $data['citys'] = City::where('status', '1')
    ->get();
    
    return view('mainpage.customer',$data);


}

public function bookslot(Request $req)
{
    Booking::create($req->all());
    $lastid = DB::getPdo()->lastInsertId();

    DB::table('bookings')->where('id', $lastid)->update(['status' => '0']);
   
    return redirect('/booking-history');

}

public function bookinghistory()
{
    
   $userid= Auth::user()->id;
//    echo $userid;
//    exit;
    $data['bookings'] = DB::table('bookings')->where('userid', $userid)
    ->orderby('slotdate','desc')->get();
    // print_r($data['bookings']);
    // exit;


    return view('mainpage.bookinghistory',$data);

}

public function bookingsdata()
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('servicecenterid', $userid)->where('status', '0')
    ->get();
    return view('dashboard.servicecenterbooking',$data);

}


public function confirm_booking($id)
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('id', $id)
    ->get();
    return view('dashboard.confirmnow',$data);

}


public function confirmwork(Request $req)
{
   
   DB::table('bookings')->where('id', $req->bookingid)->update(['status' => '1','employee_id'=>$req->employee_id]);
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/confirm-list');

}
public function confirmlist()
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('servicecenterid', $userid)->where('status', '1')
    ->get();
    return view('dashboard.confirmlist',$data);

}
public function confirmcomplete($id)
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('id', $id)
    ->get();
    return view('dashboard.bill',$data);

}
public function billdetails(Request $req)
{
   
    Bill::create($req->all());
    $lastid = DB::getPdo()->lastInsertId();

    $bkd=Bill::where('id', $lastid)
    ->value('bookingid');
    $total = $req->total;
    $bookingid = $req->bookingid;

    DB::table('bookings')->where('id', $bkd)->update(['status' => '2','amount'=>$total,'billid'=>$lastid]);
    
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/Finished');

}
public function Finished()
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('servicecenterid', $userid)->where('status', '2')
    ->get();
    return view('dashboard.finishedlist',$data);

}


public function creview($id)
{
//    $userid= Auth::user()->id;
//    $data['bookings'] = Booking::where('id', $id)
//     ->get();
    return view('mainpage.review')->with('cid',$id);

}

public function sendreview(Request $req)
{
   $userid= Auth::user()->id;
   $bookingid = $req->userid;

   DB::table('bookings')->where('id', $bookingid)->update(['review'=>$req->review,'rating'=>$req->rating]);

   $servicecenterid =  DB::table('bookings')->where('id', $bookingid)->value('servicecenterid');

   $rvalue =  DB::table('users')->where('id', $servicecenterid)->value('totalrate');
   $scount =  DB::table('users')->where('id', $servicecenterid)->value('totalservice');
   $snewval = $scount + 1 ;

   $newrvalue = $rvalue + $req->rating;

   $rvals = round($newrvalue/ $snewval);

   DB::table('users')->where('id', $servicecenterid)->update(['totalrate'=>$newrvalue,'totalservice'=>$snewval,'rating'=>$rvals]);


//    DB::table('bookings')->where('id', $bookingid)->update(['review'=>$req->review]);

          
   // return view('dashboard.confirmlist',$data);
   return redirect('/booking-history');

}

public function fullbill($id)
{
//    $userid= Auth::user()->id;
   $bill = Bill::where('bookingid', $id)
    ->get();
    return view('mainpage.fullbill')->with('bill',$bill);

}
public function billbyservice($id)
{
//    $userid= Auth::user()->id;
   $bill = Bill::where('bookingid', $id)
    ->get();
    return view('dashboard.fullbill')->with('bill',$bill);

}




public function contactus(Request $req)
{
   
   
        ContactUs::create($req->all());
        $lastid = DB::getPdo()->lastInsertId();

        DB::table('contactus')->where('id', $lastid)->update(['status' => '1']);
      

     

        return redirect('/web');
    }

    public function Contactmessage()
{
//    $userid= Auth::user()->id;
   $bill = DB::table('contactus')->get();
    return view('dashboard.contactmessage')->with('bill',$bill);

}



public function book_service_by_cs($id)
{
    

    $service_center_id =   $id;
    // echo $service_center_id;
    // exit;

    $producttype = ProductType::where('status', '1')
    ->get();
        // return redirect('/customerhome')->with('service_center_id', $service_center_id);
    return  view('mainpage.book_appoinment')->with('service_center_id',$service_center_id)->with('producttype',$producttype);

     


}



public function change_booking($id)
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('id', $id)
    ->get();
    return view('dashboard.changenow',$data);

}



public function changework(Request $req)
{
   
   DB::table('bookings')->where('id', $req->bookingid)->update(['status' => '3','cdate'=>$req->cdate,'ctime'=>$req->ctime]);
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/changed-list');

}

public function changedlist()
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('servicecenterid', $userid)->where('status', '3')->orWhere('status', '5')
    ->get();
    return view('dashboard.changedlist',$data);

}
public function declinebooking(Request $req)
{
   
   DB::table('bookings')->where('id', $req->bookingid)->update(['status' => '6']);
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/declined-list');

}


public function declinebookingbyuser($id)
{
   
   DB::table('bookings')->where('id', $id)->update(['status' => '4']);
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/booking-history');

}



public function change_bookingbyuser($id)
{
   
   DB::table('bookings')->where('id', $id)->update(['status' => '5']);
           
    // return view('dashboard.confirmlist',$data);
    return redirect('/booking-history');

}


public function declinedlist()
{
   $userid= Auth::user()->id;
   $data['bookings'] = Booking::where('servicecenterid', $userid)->where('status', '6')
    ->get();
    return view('dashboard.declinedlist',$data);

}
}
