<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Redirect;
use DB;
use View;
use Session;
use Auth;
use File;
use App\User;

class UserController extends Controller
{
    //

    public function usersignup(Request $req)
    {
        // $this->uservalidation($req);
        $pass = $req->input('password');

        $req['password'] = bcrypt($pass);
        User::create($req->all());
        $lastid = DB::getPdo()->lastInsertId();

        DB::table('users')->where('id', $lastid)->update(['status' => '1']);

        //return redirect('/login')->withErrors(['Registartion Completed Successfully!!']);

		return redirect('/users')->withErrors(['User Added Succesfully!!']);
    }
    public function uservalidation($request)
    {
    	return $this->Validate($request, [
    		'name' => 'required|max:255',
    		'email' => 'required|max:255',
    		'contact' => 'required|min:10',
            'password' => 'required|string|min:6',
        ]);
    }


    public function login(Request $req)
    {
        // $this->Validate($req, [
        //     'username' => 'required|string|max:255',
        //     'password' => 'required|string|min:6',
        // ]);
        // echo "hai";
        // echo $req->password;
        // exit;

        
        if(Auth::attempt(['email' => $req->email, 'password' => $req->password])){

            $utype=Auth::user()->usertype;
           
            if($utype=='Admin')
            {
                return redirect('/index');
            }
            elseif($utype=='superadmin')
            {
                return redirect('/index');
            }
            elseif($utype=='Customer')
            {
                $service_center_id='';
                return redirect('/customerhome')->with('service_center_id',$service_center_id);
            }
            elseif($utype=='Service Center')
            {
                return redirect('/index');
            }
            else
            {
                return redirect('/')->withErrors(['Ooops Something Wrong Happens!! Please try agian or Contact Admin!!']);
            }
            
        }
        else
        {
        	return redirect('/web#service-center')->withErrors(['Ooops Something Wrong Happens!! Please try agian or Contact Admin!!']);
        }
    }

    public function editUsers(Request $req)
    {
        

        $pass = $req->input('password');
       
        $uid = $req->input('uid');
        $name = $req->input('name');
        $designation = $req->input('designation');
        $area_of_operation = $req->input('area_of_operation');
        $mobile_number = $req->input('mobile_number');
        $email = $req->input('email');
        $access_report = $req->input('access_report');
        $access_stafflisting = $req->input('access_stafflisting');
        $access_addstudents = $req->input('access_addstudents');
        $access_studentlisting = $req->input('access_studentlisting');
        $usertype = $req->input('usertype');
        $year = $req->input('year');
        $addedby = $req->input('addedby');
        $added_time = $req->input('added_time');
        $edited_time = $req->input('edited_time');
        $added_date = $req->input('added_date');
        $edited_date = $req->input('edited_date');
        $status = $req->input('status');
        $description = $req->input('description');
        $access_create_course = $req->input('access_create_course');
        $access_create_class = $req->input('access_create_class');
        $access_leads = $req->input('access_leads');

        if($pass != '')
        {
           $newpass = bcrypt($pass);

           $values = array('name' =>$name,'designation' =>$designation,'area_of_operation' => $area_of_operation,'mobile_number' => $mobile_number,
        'access_report' => $access_report,'email' => $email,'password' => $newpass,
        'usertype' => $usertype,'addedby' => $addedby,'added_time' => $added_time,
       'edited_time' => $edited_time,'added_date' =>$added_date,'description' =>$description,
       'access_create_course' =>$access_create_course,'access_create_class' =>$access_create_class,
        'access_stafflisting' =>$access_stafflisting,'access_leads'=>$access_leads,'status' =>'1');

        }
        else
        {
            $values = array('name' =>$name,'designation' =>$designation,'area_of_operation' => $area_of_operation,'mobile_number' => $mobile_number,
        'access_report' => $access_report,'email' => $email,
        'usertype' => $usertype,'addedby' => $addedby,'added_time' => $added_time,
       'edited_time' => $edited_time,'added_date' =>$added_date,'description' =>$description,
       'access_create_course' =>$access_create_course,'access_create_class' =>$access_create_class,
        'access_stafflisting' =>$access_stafflisting,'access_leads'=>$access_leads,'status' =>'1');
        // print_r($values);
        // exit;
        }

        DB::table('users')
                          ->where('id', $uid)
                          ->update($values);
                          return redirect('/users')->withErrors(['User Details Updated Successfully!!']);

            
           
    }
    public function logout() 
    {
        Auth::logout(); // logout user
        Session::flush();
        Redirect::back();
        // $url = 'http://dsynxpo.com/';
        // return Redirect::to($url);
        return redirect('/web')->withErrors(['You are Loggedout Succesfully!!']);
    }

    public function index()
    {
        if(Auth::check()=='')
        {
            return redirect('/');

        }
        else{
           
         
            return view('dashboard.index');

        }
     
    }
  

}
