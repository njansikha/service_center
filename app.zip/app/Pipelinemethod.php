<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Pipelinemethod extends Model
{
    //

    protected $table = 'pipelinemethod';
    protected $fillable = [
        'pipelinemethod',
    ];
}
